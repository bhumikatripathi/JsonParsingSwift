//
//  ViewController.swift
//  JSONParsing
//
//  Created by Urvish Patel on 10/8/17.
//  Copyright © 2017 Urvish Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//http://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=b1b15e88fa797225412429c1c50c122a1
    
     let strUrl = "http://samples.openweathermap.org/data/2.5/weather?q=London,uk&appid=b1b15e88fa797225412429c1c50c122a1"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
      // callWebserviceWithNative()
        callWebserviceWithAlamofire()
    }

    func callWebserviceWithNative(){
       
        
        Webservice.wsCallGetService(self, aStrURL: strUrl, param: nil, useToken: false, showIndicator: false) { (response, error, str) in
            
            if error != nil{
                
                print("error : \(String(describing: error))")
            }
            else{
                
                print("Response : \(String(describing: response))")
                print("str : \(String(describing: str))")
                
                print("Weather : \(response!["weather"][0])")
                print("Humidity : \(response!["main"]["humidity"])")
            }
            
            
            
        }
    }
    
    
    func callWebserviceWithAlamofire() {
        Webservice.wsCallGet(self, aStrURL: strUrl, param: nil, useToken: false, showIndicator: false) { (response, error, str) in
            if error != nil{
                
                print("error : \(String(describing: error))")
            }
            else{
                
                print("Response : \(String(describing: response))")
                print("str : \(String(describing: str))")
                
                print("Weather : \(response!["weather"][0])")
                print("Humidity : \(response!["main"]["humidity"])")
                
                let arrWeather = response!["weather"]
                print("arrWeather  : \(arrWeather)")
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

