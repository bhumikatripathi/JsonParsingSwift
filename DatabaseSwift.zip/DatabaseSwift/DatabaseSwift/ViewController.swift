//
//  ViewController.swift
//  DatabaseSwift
//
//  Created by Urvish Patel on 10/9/17.
//  Copyright © 2017 Urvish Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        selectAll()
        insert()
        update()
        delete()
    }
    
    func selectAll() {
        
        var arrSelect = [[String:AnyObject]]()
        let querySelect = "select * from tblEmpDetails"
        arrSelect = Database().getData(query: querySelect, fail: { (str) in
            
        })
        
        print("arrSelect \(arrSelect)")
    }
    
    func insert() {
        
        let queryInsert = "insert into tblEmpDetails(name,designation) values('pqr123','jquery')"
        
        Database().insert(query:queryInsert , success: {
            print("Inserted Successfully")
        }) { (str) in
            
        }
    }
    
    
    func update() {
        let queryUpdate = "update tblEmpDetails set designation = 'android' where id = \(1)"
        Database().update(query: queryUpdate, success: {
              print("Updated Successfully")
        }) { (str) in
            
        }
    }
    
    func delete() {
        
         let querydelete = "delete from tblEmpDetails where id = \(2)"
        Database().delete(query:querydelete , success: {
            print("Delete Successfully")
        }) { (str) in
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

