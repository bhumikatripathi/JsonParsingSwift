//
//  DatabaseSwift-Bridging-Header.h
//  DatabaseSwift
//
//  Created by Urvish Patel on 10/9/17.
//  Copyright © 2017 Urvish Patel. All rights reserved.
//

#ifndef DatabaseSwift_Bridging_Header_h
#define DatabaseSwift_Bridging_Header_h

#import <sqlite3.h>

#endif /* DatabaseSwift_Bridging_Header_h */
